import socket
import threading
import tkinter as tk
from tkinter import ttk
from datetime import datetime
import base64
from ttkthemes import ThemedTk

class ChatServer:
    def __init__(self, host='0.0.0.0', port=55000):
        self.host = host
        self.port = port
        self.server_socket = None
        self.clients = {}
        self.nicknames = {}
        self.profile_pictures = {}
        self.running = False
        self.file_buffers = {}  # Initialize file_buffers here

        # Main Window with Modern Theme
        self.root = ThemedTk(theme="arc")
        self.root.title("Modern Chat Server")
        self.root.geometry("500x500")
        self.root.configure(bg='#006c84')

        # Style Configuration
        self.style = ttk.Style()
        self.style.configure('Modern.TFrame', background='#006c84')
        self.style.configure('Chat.TFrame', background='#6eb5c0')
        self.style.configure('Modern.TButton', 
                           background='#006c84',
                           foreground='black',
                           padding=10)
        self.style.configure('Header.TLabel',
                           background='#006c84',
                           foreground='black',
                           font=('Helvetica', 12, 'bold'))

        # Main Container
        self.main_container = ttk.Frame(self.root, style='Modern.TFrame')
        self.main_container.pack(fill=tk.BOTH, expand=True, padx=20, pady=20)

        # Header Frame
        self.header_frame = ttk.Frame(self.main_container, style='Modern.TFrame')
        self.header_frame.pack(fill=tk.X, pady=(0, 10))

        # Server Status
        self.status_label = ttk.Label(self.header_frame,
                                    text="Server Stopped",
                                    style='Header.TLabel')
        self.status_label.pack(side=tk.RIGHT, padx=10)

        # Chat Area Container
        self.chat_container = ttk.Frame(self.main_container, style='Chat.TFrame')
        self.chat_container.pack(fill=tk.BOTH, expand=True)

        # Chat Log with Custom Styling
        self.chat_frame = ttk.Frame(self.chat_container, style='Chat.TFrame')
        self.chat_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Custom Chat Log
        self.chat_log = tk.Text(self.chat_frame,
                               wrap=tk.WORD,
                               font=('Helvetica', 10),
                               bg='#6eb5c0',
                               fg='#333333',
                               relief=tk.FLAT)
        self.chat_log.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.chat_log.tag_configure('server',
                                  justify='left',
                                  background='#006c84',
                                  foreground='white',
                                  spacing1=5,
                                  spacing3=5)
        self.chat_log.tag_configure('client',
                                  justify='left',
                                  background='white',
                                  foreground='#333333',
                                  spacing1=5,
                                  spacing3=5)

        # Modern Scrollbar
        self.scrollbar = ttk.Scrollbar(self.chat_frame,
                                     orient='vertical',
                                     command=self.chat_log.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.chat_log['yscrollcommand'] = self.scrollbar.set

        # Input Area
        self.input_container = ttk.Frame(self.main_container, style='Modern.TFrame')
        self.input_container.pack(fill=tk.X, pady=10)

        # Message Entry
        self.msg_frame = ttk.Frame(self.input_container, style='Modern.TFrame')
        self.msg_frame.pack(fill=tk.X, pady=5)

        self.message_entry = ttk.Entry(self.msg_frame,
                                     font=('Helvetica', 10))
        self.message_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        self.send_button = ttk.Button(self.msg_frame,
                                    text="Send to All",
                                    command=self.send_message_to_all,
                                    style='Modern.TButton')
        self.send_button.pack(side=tk.RIGHT)

        # Server Control Buttons
        self.button_frame = ttk.Frame(self.main_container, style='Modern.TFrame')
        self.button_frame.pack(fill=tk.X, pady=10)

        self.start_button = ttk.Button(self.button_frame,
                                     text="Start Server",
                                     command=self.start_server,
                                     style='Modern.TButton')
        self.start_button.pack(side=tk.LEFT, padx=5)

        self.stop_button = ttk.Button(self.button_frame,
                                    text="Stop Server",
                                    command=self.stop_server,
                                    style='Modern.TButton',
                                    state=tk.DISABLED)
        self.stop_button.pack(side=tk.LEFT, padx=5)

        # Bind enter key to send message
        self.message_entry.bind('<Return>', lambda e: self.send_message_to_all())

    def broadcast(self, message, _client=None):
        for client in self.clients.values():
            if client != _client:
                try:
                    client.send(message)
                except:
                    self.remove_client(client)

    def handle_profile_picture(self, client, nickname):
        try:
            client.send('PROFILE_PIC'.encode('utf-8'))
            profile_pic_data = client.recv(1048576)
            if profile_pic_data:
                self.profile_pictures[nickname] = profile_pic_data
                profile_update = f"PROFILE_UPDATE:{nickname}:{base64.b64encode(profile_pic_data).decode('utf-8')}"
                self.broadcast(profile_update.encode('utf-8'))
        except Exception as e:
            self.update_chat_log(f"Error handling profile picture for {nickname}: {e}")

    def handle_file_transfer(self, sender_client, message):
        try:
            # Parse file info from message
            file_info = message.split(':', 2)
            if len(file_info) == 3:
                file_name = file_info[1]
                file_data = file_info[2]
                
                # Handle padding
                padding_needed = len(file_data) % 4
                if padding_needed:
                    file_data += '=' * (4 - padding_needed)
                
                try:
                    # Verify data is valid base64
                    decoded_data = base64.b64decode(file_data)
                    file_size = len(decoded_data)
                    
                    # Check file size
                    if file_size > 100 * 1024 * 1024:  # 100MB limit
                        sender_client.send("ERROR:File too large (max 100MB)".encode('utf-8'))
                        return

                    # Get file extension
                    file_ext = file_name.lower().split('.')[-1] if '.' in file_name else ''
                    
                    # Create message with file type info
                    file_message = f"FILE:{file_name}:{file_ext}:{file_data}"
                    
                    # Broadcast file to all clients
                    self.broadcast(file_message.encode('utf-8'), sender_client)
                    self.update_chat_log(f"File '{file_name}' transferred successfully", 'server')
                    
                except Exception as e:
                    self.update_chat_log(f"Error processing file data: {e}", 'server')
                    
        except Exception as e:
            self.update_chat_log(f"Error in file transfer: {e}", 'server')

    def handle_client(self, client, nickname):
        # Send existing profile pictures to new client
        for existing_nick, profile_pic in self.profile_pictures.items():
            profile_data = f"PROFILE_UPDATE:{existing_nick}:{base64.b64encode(profile_pic).decode('utf-8')}"
            client.send(profile_data.encode('utf-8'))

        while self.running:
            try:
                message = client.recv(65536)
                if not message:
                    self.remove_client(client)
                    break

                decoded_message = message.decode('utf-8')
                self.save_message_to_file(decoded_message)

                if decoded_message.startswith("MSG:"):
                    self.broadcast(message, client)
                    self.update_chat_log(f"{decoded_message[4:]}", 'client')
                elif decoded_message.startswith("PRIVATE:"):
                    parts = decoded_message.split(':', 3)
                    recipient = parts[1]
                    if recipient in self.clients:
                        self.clients[recipient].send(message)
                elif decoded_message.startswith("FILE:"):
                    self.handle_file_transfer(client, decoded_message)
                elif decoded_message.startswith("PROFILE_UPDATE:"):
                    parts = decoded_message.split(':', 2)
                    if len(parts) == 3:
                        _, nick, pic_data = parts
                        self.profile_pictures[nick] = base64.b64decode(pic_data)
                        self.broadcast(message, client)
            except Exception as e:
                self.update_chat_log(f"An error occurred: {e}", 'server')
                self.remove_client(client)
                break

    def save_message_to_file(self, message):
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open("chat_log.txt", "a", encoding='utf-8') as file:
            file.write(f"[{timestamp}] {message}\n")

    def remove_client(self, client):
        for nickname, c in self.clients.items():
            if c == client:
                break
        del self.clients[nickname]
        del self.nicknames[nickname]
        client.close()
        self.broadcast(f"MSG:{nickname} left the chat!\n".encode('utf-8'))
        self.update_chat_log(f"{nickname} left the chat!", 'server')

    def accept_connections(self):
        while self.running:
            try:
                client, address = self.server_socket.accept()
                client.send('NICKNAME'.encode('utf-8'))
                nickname = client.recv(1024).decode('utf-8')

                self.clients[nickname] = client
                self.nicknames[nickname] = client

                self.update_chat_log(f"{nickname} connected!", 'server')
                client.send('Connected to the server!'.encode('utf-8'))

                thread = threading.Thread(target=self.handle_client, args=(client, nickname))
                thread.start()
            except Exception as e:
                if self.running:
                    self.update_chat_log(f"An error occurred: {e}", 'server')
                break

    def send_message_to_all(self):
        message = self.message_entry.get().strip()
        if message:
            formatted_message = f"MSG:Server: {message}"
            self.update_chat_log(f"Server: {message}", 'server')
            self.message_entry.delete(0, tk.END)
            self.broadcast(formatted_message.encode('utf-8'))

    def update_chat_log(self, message, tag='server'):
        timestamp = datetime.now().strftime("%H:%M")
        self.chat_log.config(state=tk.NORMAL)
        self.chat_log.insert(tk.END, f"[{timestamp}] {message}\n", tag)
        self.chat_log.see(tk.END)
        self.chat_log.config(state=tk.DISABLED)

    def start_server(self):
        if not self.running:
            self.running = True
            self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(5)

            self.start_button.config(state=tk.DISABLED)
            self.stop_button.config(state=tk.NORMAL)
            self.status_label.config(text="Server Running")

            server_thread = threading.Thread(target=self.accept_connections)
            server_thread.start()

            self.update_chat_log("Server Started...", 'server')

    def stop_server(self):
        if self.running:
            self.running = False
            for client in self.clients.values():
                client.close()
            self.clients.clear()
            self.nicknames.clear()

            if self.server_socket:
                self.server_socket.close()
                self.server_socket = None

            self.start_button.config(state=tk.NORMAL)
            self.stop_button.config(state=tk.DISABLED)
            self.status_label.config(text="Server Stopped")

            self.update_chat_log("Server Stopped...", 'server')

    def center_window(self):
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        x = (screen_width - 800) // 2
        y = (screen_height - 600) // 2
        self.root.geometry(f"800x600+{x}+{y}")

    def create_tooltip(self, widget, text):
        def enter(event):
            self.tooltip = tk.Toplevel()
            self.tooltip.wm_overrideredirect(True)
            self.tooltip.wm_geometry(f"+{event.x_root+10}+{event.y_root+10}")
            
            label = ttk.Label(self.tooltip, text=text, background="#ffffe0", relief='solid', borderwidth=1)
            label.pack()

        def leave(event):
            if hasattr(self, 'tooltip'):
                self.tooltip.destroy()

        widget.bind('<Enter>', enter)
        widget.bind('<Leave>', leave)

    def add_tooltips(self):
        self.create_tooltip(self.send_button, "Send message to all clients (Enter)")
        self.create_tooltip(self.start_button, "Start the chat server")
        self.create_tooltip(self.stop_button, "Stop the chat server")

    def run(self):
        self.add_tooltips()
        self.center_window()
        try:
            self.root.iconbitmap('server_icon.ico')
        except:
            pass
        self.root.protocol("WM_DELETE_WINDOW", self.stop_server)
        self.root.mainloop()

if __name__ == "__main__":
    server = ChatServer()
    server.run()