import socket
import threading
import tkinter as tk
from tkinter import filedialog, simpledialog, ttk
import base64
import os
from datetime import datetime
from PIL import Image, ImageTk
import io
from ttkthemes import ThemedTk

class ModernChatClient:
    def __init__(self):
        self.client = None
        self.host = '192.168.141.17'
        self.port = 55000
        self.nickname = ""
        self.profile_pic = None
        self.running = False
        self.profile_pics = {}

       # Main Window with Modern Theme
        self.root = ThemedTk(theme="arc")
        self.root.title("Modern Chat")
        self.root.geometry("600x450")
        self.root.configure(bg='#006c84')

        # Style Configuration
        self.style = ttk.Style()
        self.style.configure('Modern.TFrame', background='#006c84')
        self.style.configure('Chat.TFrame', background='#6eb5c0')
        self.style.configure('Modern.TButton', 
                           background='#006c84',
                           foreground='black',
                           padding=5)
        self.style.configure('Header.TLabel',
                           background='#006c84',
                           foreground='black',
                           font=('Helvetica', 12, 'bold'))

        # Main Container
        self.main_container = ttk.Frame(self.root, style='Modern.TFrame')
        self.main_container.pack(fill=tk.BOTH, expand=True, padx=20, pady=5)

        # Header Frame
        self.header_frame = ttk.Frame(self.main_container, style='Modern.TFrame')
        self.header_frame.pack(fill=tk.X, pady=(0, 10))

        # Profile Section
        self.profile_frame = ttk.Frame(self.header_frame, style='Modern.TFrame')
        self.profile_frame.pack(side=tk.LEFT, padx=10)
        
        self.profile_label = ttk.Label(self.profile_frame, 
                                     text="No Profile Picture",
                                     style='Header.TLabel')
        self.profile_label.pack(side=tk.LEFT, padx=5)

        # Connection Status
        self.status_label = ttk.Label(self.header_frame,
                                    text="Disconnected",
                                    style='Header.TLabel')
        self.status_label.pack(side=tk.RIGHT, padx=10)

        # Chat Area Container
        self.chat_container = ttk.Frame(self.main_container, style='Chat.TFrame')
        self.chat_container.pack(fill=tk.BOTH, expand=True)

        # Chat Log with Custom Styling
        self.chat_frame = ttk.Frame(self.chat_container, style='Chat.TFrame')
        self.chat_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Custom Chat Log
        self.chat_log = tk.Text(self.chat_frame,
                               wrap=tk.WORD,
                               font=('Helvetica', 10),
                               bg='#6eb5c0',
                               fg='#333333',
                               relief=tk.FLAT)
        self.chat_log.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self.chat_log.tag_configure('sent',
                                  justify='right',
                                  background='#006c84',
                                  foreground='white',
                                  spacing1=5,
                                  spacing3=5,
                                  lmargin2=50)
        self.chat_log.tag_configure('received',
                                  justify='left',
                                  background='white',
                                  foreground='#333333',
                                  spacing1=5,
                                  spacing3=5,
                                  rmargin=50)

        # Modern Scrollbar
        self.scrollbar = ttk.Scrollbar(self.chat_frame,
                                     orient='vertical',
                                     command=self.chat_log.yview)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.chat_log['yscrollcommand'] = self.scrollbar.set

        # Input Area
        self.input_container = ttk.Frame(self.main_container, style='Modern.TFrame')
        self.input_container.pack(fill=tk.X, pady=10)

        # Message Entry
        self.msg_frame = ttk.Frame(self.input_container, style='Modern.TFrame')
        self.msg_frame.pack(fill=tk.X, pady=5)

        self.msg_entry = ttk.Entry(self.msg_frame,
                                 font=('Helvetica', 10))
        self.msg_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        self.send_button = ttk.Button(self.msg_frame,
                                    text="Send",
                                    command=self.send_message,
                                    style='Modern.TButton',
                                    state=tk.DISABLED)
        self.send_button.pack(side=tk.RIGHT)

        # Private Message Entry
        self.private_frame = ttk.Frame(self.input_container, style='Modern.TFrame')
        self.private_frame.pack(fill=tk.X, pady=5)

        self.private_msg_entry = ttk.Entry(self.private_frame,
                                         font=('Helvetica', 10))
        self.private_msg_entry.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        self.private_button = ttk.Button(self.private_frame,
                                       text="Send Private",
                                       command=self.send_private_message,
                                       style='Modern.TButton',
                                       state=tk.DISABLED)
        self.private_button.pack(side=tk.RIGHT)

        # File Transfer Area
        self.file_frame = ttk.Frame(self.input_container, style='Modern.TFrame')
        self.file_frame.pack(fill=tk.X, pady=5)

        self.file_progress = ttk.Progressbar(self.file_frame,
                                           orient='horizontal',
                                           length=300,
                                           mode='determinate',
                                           style='Modern.Horizontal.TProgressbar')
        self.file_progress.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(0, 5))

        self.send_file_button = ttk.Button(self.file_frame,
                                         text="Send File",
                                         command=self.send_file,
                                         style='Modern.TButton',
                                         state=tk.DISABLED)
        self.send_file_button.pack(side=tk.RIGHT)

        # Bottom Buttons
        self.button_frame = ttk.Frame(self.main_container, style='Modern.TFrame')
        self.button_frame.pack(fill=tk.X, pady=10)

        self.profile_button = ttk.Button(self.button_frame,
                                       text="Set Profile Picture",
                                       command=self.set_profile_picture,
                                       style='Modern.TButton')
        self.profile_button.pack(side=tk.LEFT, padx=5)

        self.connect_button = ttk.Button(self.button_frame,
                                       text="Connect to Server",
                                       command=self.connect_to_server,
                                       style='Modern.TButton')
        self.connect_button.pack(side=tk.LEFT, padx=5)

        # Bind enter key to send message
        self.msg_entry.bind('<Return>', lambda e: self.send_message())
        self.private_msg_entry.bind('<Return>', lambda e: self.send_private_message())

    # The rest of the methods remain the same as in your original code
    def connect_to_server(self):
        if self.running:
            self.chat_log.insert(tk.END, "Already connected to the server.\n")
            return

        try:
            self.client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.client.connect((self.host, self.port))
            self.running = True

            if not self.nickname:
                nickname_window = simpledialog.askstring("Nickname", "Enter your nickname:")
                if nickname_window:
                    self.nickname = nickname_window
                else:
                    self.disconnect_from_server()
                    return

            self.client.send(self.nickname.encode('utf-8'))
            
            response = self.client.recv(1024).decode('utf-8')
            if response == 'NICKNAME':
                receive_thread = threading.Thread(target=self.receive)
                receive_thread.start()

                self.send_button.config(state=tk.NORMAL)
                self.send_file_button.config(state=tk.NORMAL)
                self.private_button.config(state=tk.NORMAL)
                self.status_label.config(text="Connected")
                self.chat_log.insert(tk.END, "Connected to the server.\n")
            else:
                self.chat_log.insert(tk.END, f"Connection failed: {response}\n")
                self.disconnect_from_server()

        except Exception as e:
            self.chat_log.insert(tk.END, f"Could not connect to server: {e}\n")
            self.disconnect_from_server()

    def disconnect_from_server(self):
        self.running = False
        if self.client:
            try:
                self.client.close()
            except:
                pass
            self.client = None

        self.send_button.config(state=tk.DISABLED)
        self.send_file_button.config(state=tk.DISABLED)
        self.private_button.config(state=tk.DISABLED)
        self.status_label.config(text="Disconnected")
        self.chat_log.insert(tk.END, "Disconnected from the server.\n")

    def send_message(self):
        if not self.running:
            self.chat_log.insert(tk.END, "Cannot send message. Not connected to server.\n")
            return

        message = self.msg_entry.get().strip()
        if message:
            try:
                timestamp = datetime.now().strftime("%H:%M")
                formatted_message = f"MSG:{self.nickname}: {message}"
                self.client.send(formatted_message.encode('utf-8'))
                self.chat_log.insert(tk.END, f"[{timestamp}] You: {message}\n", 'sent')
                self.msg_entry.delete(0, tk.END)
            except Exception as e:
                self.chat_log.insert(tk.END, f"Error sending message: {e}\n")
                self.disconnect_from_server()

    def send_private_message(self):
        if not self.running:
            self.chat_log.insert(tk.END, "Cannot send private message. Not connected to server.\n")
            return

        recipient = simpledialog.askstring("Recipient", "Enter recipient's nickname:")
        if not recipient:
            return

        message = self.private_msg_entry.get().strip()
        if not message:
            self.chat_log.insert(tk.END, "Message cannot be empty.\n")
            return

        try:
            timestamp = datetime.now().strftime("%H:%M")
            formatted_message = f"PRIVATE:{recipient}:{self.nickname}: {message}"
            self.client.send(formatted_message.encode('utf-8'))
            self.chat_log.insert(tk.END, f"[{timestamp}] Private to {recipient}: {message}\n", 'sent')
            self.private_msg_entry.delete(0, tk.END)
        except Exception as e:
            self.chat_log.insert(tk.END, f"Error sending private message: {e}\n")
            self.disconnect_from_server()

    def send_file(self):
        if not self.running:
            self.chat_log.insert(tk.END, "Cannot send file. Not connected to server.\n")
            return

        file_path = filedialog.askopenfilename(
            title="Select File",
            filetypes=[("All files", "*.*")]
        )

        if file_path:
            try:
                file_size = os.path.getsize(file_path)
                if file_size > 100 * 1024 * 1024:  # 100MB limit
                    self.chat_log.insert(tk.END, "File too large (max 100MB)\n")
                    return

                self.file_progress['value'] = 0
                self.file_progress['maximum'] = file_size
                
                with open(file_path, 'rb') as file:
                    file_data = file.read(1024 * 1024)  # Read in 1MB chunks
                    while file_data:
                        encoded_file = base64.b64encode(file_data).decode('utf-8')
                        padding = '=' * (4 - len(encoded_file) % 4)
                        encoded_file += padding
                        
                        file_message = f"FILE:{os.path.basename(file_path)}:{encoded_file}"
                        self.client.send(file_message.encode('utf-8'))

                        self.chat_log.insert(tk.END, f"Sent file: {os.path.basename(file_path)}\n")
                        self.file_progress['value'] += len(file_data)
                        file_data = file.read(1024 * 1024)

            except Exception as e:
                self.chat_log.insert(tk.END, f"Error sending file: {e}\n")
            finally:
                self.file_progress['value'] = 0

    def set_profile_picture(self):
        file_path = filedialog.askopenfilename(
            title="Select Profile Picture",
            filetypes=[("Image files", "*.jpg *.jpeg *.png")]
        )

        if file_path:
            try:
                with Image.open(file_path) as img:
                    img = img.resize((50, 50), Image.Resampling.LANCZOS)
                    img_byte_arr = io.BytesIO()
                    img.save(img_byte_arr, format=img.format)
                    self.profile_pic = img_byte_arr.getvalue()
                    
                    photo = ImageTk.PhotoImage(img)
                    self.profile_label.config(image=photo)
                    self.profile_label.image = photo
                    
                    if self.running:
                        update_message = f"PROFILE_UPDATE:{self.nickname}:{base64.b64encode(self.profile_pic).decode('utf-8')}"
                        self.client.send(update_message.encode('utf-8'))
                        
            except Exception as e:
                self.chat_log.insert(tk.END, f"Error setting profile picture: {e}\n")

    def receive(self):
        while self.running:
            try:
                message = self.client.recv(65536).decode('utf-8')
                timestamp = datetime.now().strftime("%H:%M")
                
                if not message:
                    raise ConnectionError("Connection lost")

                if message.startswith("MSG:"):
                    try:
                        _, sender, text = message.split(":", 2)
                        self.chat_log.insert(tk.END, f"[{timestamp}] {sender}: {text}\n", 'received')
                    except ValueError:
                        self.chat_log.insert(tk.END, f"[{timestamp}] Invalid message format\n")
                
                elif message.startswith("PRIVATE:"):
                    try:
                        _, recipient, sender, private_msg = message.split(":", 3)
                        if recipient == self.nickname:
                            self.chat_log.insert(tk.END, f"[{timestamp}] Private from {sender}: {private_msg}\n", 'received')
                    except ValueError:
                        self.chat_log.insert(tk.END, f"[{timestamp}] Invalid private message format\n")
                
                elif message.startswith("FILE:"):
                    try:
                        file_name, encoded_file = message[5:].split(":", 1)
                        padding = '=' * (4 - len(encoded_file) % 4)
                        encoded_file += padding

                        file_data = base64.b64decode(encoded_file)
                        received_file_path = f"received_{file_name}"
                        
                        with open(received_file_path, 'wb') as file:
                            file.write(file_data)
                        
                        self.chat_log.insert(tk.END, f"[{timestamp}] Received file: {file_name}\n", 'received')
                        
                        if os.name == 'nt':  # Windows
                            os.startfile(received_file_path)
                        elif os.name == 'posix':  # Linux/Mac
                            os.system(f'xdg-open "{received_file_path}"')

                    except Exception as e:
                        self.chat_log.insert(tk.END, f"[{timestamp}] Error receiving file: {e}\n")

                self.chat_log.see(tk.END)
                
            except Exception as e:
                if self.running:
                    self.chat_log.insert(tk.END, f"Disconnected from server: {e}\n")
                    self.disconnect_from_server()
                break

    def run(self):
        # Add emojis and file type support
        self.supported_file_types = {
            '.txt': '📄', '.pdf': '📕', '.doc': '📘', '.docx': '📘',
            '.jpg': '🖼️', '.jpeg': '🖼️', '.png': '🖼️', '.gif': '🖼️',
            '.mp3': '🎵', '.wav': '🎵', '.mp4': '🎥', '.avi': '🎥',
            '.zip': '📦', '.rar': '📦'
        }

        # Add tooltips
        self.add_tooltips()

        # Center window on screen
        self.center_window()

        # Set window icon (if available)
        try:
            self.root.iconbitmap('chat_icon.ico')
        except:
            pass

        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)
        self.root.mainloop()

    def add_tooltips(self):
        # Create tooltips for buttons
        self.create_tooltip(self.send_button, "Send message (Enter)")
        self.create_tooltip(self.private_button, "Send private message")
        self.create_tooltip(self.send_file_button, "Send a file to chat")
        self.create_tooltip(self.profile_button, "Set your profile picture")
        self.create_tooltip(self.connect_button, "Connect to chat server")

    def create_tooltip(self, widget, text):
        def enter(event):
            self.tooltip = tk.Toplevel()
            self.tooltip.wm_overrideredirect(True)
            self.tooltip.wm_geometry(f"+{event.x_root+10}+{event.y_root+10}")
            
            label = ttk.Label(self.tooltip, text=text, background="#ffffe0", relief='solid', borderwidth=1)
            label.pack()

        def leave(event):
            if hasattr(self, 'tooltip'):
                self.tooltip.destroy()

        widget.bind('<Enter>', enter)
        widget.bind('<Leave>', leave)

    def center_window(self):
        # Get screen width and height
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()

        # Calculate position
        x = (screen_width - 800) // 2
        y = (screen_height - 600) // 2

        # Set the position of the window to the center of the screen
        self.root.geometry(f"800x600+{x}+{y}")

    def on_closing(self):
        self.running = False
        if self.client:
            try:
                self.client.close()
            except:
                pass
        self.root.destroy()

if __name__ == "__main__":
    client = ModernChatClient()
    client.run()